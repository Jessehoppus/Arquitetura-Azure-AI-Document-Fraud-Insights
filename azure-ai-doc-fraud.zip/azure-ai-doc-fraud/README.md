# Azure AI — Document Fraud & Authenticity Insights

Arquitetura + API esqueleto para análise de documentos, score de fraude e explicabilidade.
